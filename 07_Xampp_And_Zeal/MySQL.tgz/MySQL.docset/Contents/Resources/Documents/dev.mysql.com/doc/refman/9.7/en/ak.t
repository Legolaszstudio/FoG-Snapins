<!DOCTYPE html>
<html lang="en" class="svg no-js">
<head>
    <meta charset="utf-8" />
    <!--[if IE ]>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
    <![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="Language" content="en">

    <title>MySQL :: Page Not Found</title>
    <link rel="stylesheet" media="all" href="https://labs.mysql.com/common/css/main-20250803.min.css" />
            <link rel="stylesheet" media="all" href="https://labs.mysql.com/common/css/page-20250803.min.css" />
    
    
    <link rel="stylesheet" media="print" href="https://labs.mysql.com/common/css/print-20250803.min.css" />

    
    
    
    
    
    <link rel="shortcut icon" href="https://labs.mysql.com/common/themes/sakila/favicon.ico" />
    <script async="async" type="text/javascript" src='https://consent.truste.com/notice?domain=oracle.com&c=teconsent&js=bb&noticeType=bb&text=true&cdn=1&pcookie&gtm=1' crossorigin></script>
    <script src="https://www.oracle.com/assets/truste-oraclelib.js"></script>
    <script>(function(H){ H.className=H.className.replace(/\bno-js\b/,'js') })(document.documentElement)</script>
    <script src="https://labs.mysql.com/common/js/site-20250121.min.js"></script>

    
    
    <!--[if lt IE 9]>
        <script src="https://labs.mysql.com/common/js/polyfills/html5shiv-printshiv-3.7.2.min.js"></script>
        <script src="https://labs.mysql.com/common/js/polyfills/respond-1.4.2.min.js"></script>
    <![endif]-->
        </head>

<body class="  dev">
<a class="skip-main" href="#main">Skip to Main Content</a>
<div class="page-wrapper">
    <header>

                        <a href="https://dev.mysql.com/" aria-label="MySQL Home" title="MySQL" id="l1-home-link"></a>
        
        <div id="l1-nav-container">
            <div id="l1-line1">
                <div id="l1-lhs">
                    <div id="l1-slogan">
                        The world's most popular open source database
                    </div>
                    <div id="l1-search-box">
                        <form id="l1-search-form" method="get" action="https://search.oracle.com/mysql">
                        <input type="hidden" name="app" value="mysql" />
                        <input id="l1-search-input" type="search" class="icon-search" placeholder="Search" aria-label="Search" name="q" />
                        </form>
                    </div>
                    <div id="l1-auth-links">
                        <nav aria-label="Contact/Login Navigation" role="navigation">
                            <a href="https://www.mysql.com/about/contact/"><b>Contact MySQL</b></a>
                            <span id="l1-contact-separator">&nbsp;|&nbsp;</span>
                            <span id="l1-contact-separator-br"><br /></span>
                                                             <a href="https://dev.mysql.com/auth/login/?dest=https%3A%2F%2Fdev.mysql.com%2Fdoc%2Frefman%2F9.7%2Fen%2Fak.t">Login</a> &nbsp;|&nbsp;
                                 <a href="https://dev.mysql.com/auth/register/">Register</a>
                                                    </nav>
                    </div>
                </div>
            </div>
            <div id="l1-line2">
                <nav aria-label="Primary Navigation" role="navigation">
                    <ul id="l1-nav">
                        <li>
                            <a href="https://www.mysql.com/"><!-- <span class="icon-sakila"></span>  -->MySQL.com</a>
                        </li><li>
                            <a href="https://www.mysql.com/downloads/"><!-- <span class="icon-download-thin"></span>  -->Downloads</a>
                        </li><li class="active">
                            <a href="/doc/"><!-- <span class="icon-books"></span>  -->Documentation</a>
                        </li><li>
                            <a href="/"><!-- <span class="icon-code"></span>  -->Developer Zone</a>
                        </li>                    </ul>
                </nav>
                <div class="social-icons">
                    <nav aria-label="Social Navigation" role="navigation">
                        <a aria-label="Join us on Facebook" title="Join us on Facebook" href="http://www.facebook.com/mysql"><span class="icon-facebook"></span></a>
                        <a aria-label="Follow us on X" title="Follow us on X" href="https://x.com/mysql"><span class="icon-x-twitter"></span></a>
                        <a aria-label="Follow us on LinkedIn" title="Follow us on LinkedIn" href="https://www.linkedin.com/company/mysql"><span class="icon-linkedin"></span></a>
                        <a aria-label="Visit our YouTube channel" title="Visit our YouTube channel" href="http://www.youtube.com/mysqlchannel"><span class="icon-youtube"></span></a>
                    </nav>
                </div>
            </div>
        </div>
        <div id="sub-header">
            <div id="l2-nav-container">
                <div id="l2-nav-toggle">
                    <span class="icon-three-bars"></span>
                </div>
                                                                                        <a class="button nav-button-3" href="/"><span class="icon-code"></span> Developer Zone</a>
                                                                                                                                    <a class="button nav-button-2" href="https://www.mysql.com/downloads/"><span class="icon-download-thin"></span> Downloads</a>
                                                                                                <a class="button nav-button-1" href="https://www.mysql.com/"><span class="icon-sakila"></span> MySQL.com</a>
                                                                        <div id="l2-search-toggle">
                    <span class="icon-search"></span>
                </div>
                <div id="l2-site-icon">
                                                                                                                                                                                                    <span class="icon-books"></span>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    </div>
                <div id="l1-section-title">
                    <span id="l1-section-label">
                        <a href="/doc/">Documentation</a>
                    </span>
                </div>
                <nav aria-label="Secondary Navigation" role="navigation">
                    

<ul id="l2-nav">
            	<li class=""><a  href="/doc/refman/en/">MySQL Server</a>
    			</li>
	        	<li class=""><a  href="/doc/index-enterprise.html">MySQL Enterprise</a>
    			</li>
	        	<li class=""><a  href="/doc/workbench/en/">Workbench</a>
    			</li>
	        	<li class=""><a  href="/doc/mysql-shell/en/mysql-innodb-cluster.html">InnoDB Cluster</a>
    			</li>
	        	<li class=""><a  href="/doc/index-cluster.html">MySQL NDB Cluster</a>
    			</li>
	        	<li class=""><a  href="/doc/index-connectors.html">Connectors</a>
    			</li>
	        	<li class=" last"><a  href="/doc/index-other.html">More</a>
    			</li>
	                        <li class="other-section"><a href="https://www.mysql.com/">MySQL.com</a></li>
                            <li class="other-section"><a href="https://www.mysql.com/downloads/">Downloads</a></li>
                                        <li class="other-section"><a href="/">Developer Zone</a></li>
            </ul>
                </nav>
            </div>
            <div id="l3-search-container"></div>
            <div id="top-orange"><span id="section-nav">Section Menu: &nbsp; </span></div>
        </div>
    </header>
        <div id="page">
                <div id="sidebar">

            
                <div id="menu">
                    <nav aria-label="Tertiary Navigation" role="navigation">
                        

<ul>
        	<li class=" level1"><a  href="/doc/refman/en/"><span class="icon-dot"></span>MySQL Reference Manual</a>
    			</li>
	        	<li class=" last level1"><a  href="/doc/relnotes/mysql/en/"><span class="icon-dot"></span>MySQL Release Notes</a>
    			</li>
	</ul>
                    </nav>
                    <br class="clear" />
                </div>

                
                
                    
                    
                    
                    
                    
                    
                    
                                    </div>
                
                <div role="main" id="main" tabindex="-1">

            
            <div id="content">
                                                        <h1 class="page-title" id="mainContent">Page Not Found
                                        </h1>
                                                
                
    <p>We're sorry, the page or file you requested was not found on this server.</p>

<p>You may wish to:
    <ul>
                                    <li><a href="https://dev.mysql.com/doc/">View our Documentation Library</a></li>
                <li><a href="https://dev.mysql.com/doc/index-archive.html">View our Documentation Archive</a></li></li>
                <li>
                    Search our Current Documentation:
                    <form name="search" method="GET" action="https://dev.mysql.com/doc/search/" style="margin: 8px 0;">
                        <input type="text" size="20" name="q" />
                        <input type="submit" value="Search" />
                    </form>
                </li>
                            <li><a href="https://dev.mysql.com/sitemap.html">View our Site Map</a></li>
        <li><a href="http://search.oracle.com/search/search?group=MySQL">Search our site</a></li>
        <li><a href="https://www.mysql.com/about/contact/feedback.php">Report a broken link or missing page</a></li>
    </ul>
</p>

<br /><br />


                        </div>
            
        </div>
    </div>

    <footer>
        <div id="footer-bottom">
                                    <div class="footer-contact">
                <div id="footer-contact-icon">
                    <span class="icon-call-phone"></span>
                </div>
                <div id="footer-contact-numbers">
                    <strong>Contact MySQL Sales</strong><br/>
                    USA/Canada: +1-866-221-0634 &nbsp;
                    (<a href="https://www.mysql.com/about/contact/phone/" class="darker-blue">More Countries &raquo;</a>)
                </div>
                <div id="footer-contact-copyright">
                    <a href="http://www.oracle.com/" aria-label="Oracle" title="Oracle"><span class="oracle-logo"></span></a>
                    &nbsp; <a href="https://www.oracle.com/legal/copyright.html">&copy; 2026 Oracle</a>
                </div>
            </div>
            <div class="social-icons">
                <a aria-label="Join us on Facebook" title="Join us on Facebook" href="http://www.facebook.com/mysql"><span class="icon-facebook-square"></span></a>
                <a aria-label="Follow us on X" title="Follow us on X" href="https://x.com/mysql"><span class="icon-x-twitter-square"></span></a>
                <a aria-label="Follow us on LinkedIn" title="Follow us on LinkedIn" href="https://www.linkedin.com/company/mysql"><span class="icon-linkedin-square"></span></a>
                <a aria-label="Visit our YouTube channel" title="Visit our YouTube channel" href="http://www.youtube.com/mysqlchannel"><span class="icon-youtube-square"></span></a>
            </div>
            <br class="clear" />
        </div>
        <div id="footer-links">

            <div id="site-footer-links">
                <div id="footer-nav"></div>

                <div class="links">
                    <ul>
                        <li class="top"><a href="https://www.mysql.com/products/">Products</a></li>
                        <li><a href="https://www.mysql.com/products/heatwave/">MySQL HeatWave</a></li>
                        <li><a href="https://www.mysql.com/products/enterprise/">MySQL Enterprise Edition</a></li>
                        <li><a href="https://www.mysql.com/products/standard/">MySQL Standard Edition</a></li>
                        <li><a href="https://www.mysql.com/products/classic/">MySQL Classic Edition</a></li>
                        <li><a href="https://www.mysql.com/products/cluster/">MySQL Cluster CGE</a></li>
                        <li><a href="https://www.mysql.com/oem/">MySQL Embedded (OEM/ISV)</a></li>
                    </ul>
                </div>

                <div class="links">
                    <ul>
                        <li class="top"><a href="https://www.mysql.com/services/">Services</a></li>
                        <li><a href="https://www.mysql.com/training/">Training</a></li>
                        <li><a href="https://www.mysql.com/certification/">Certification</a></li>
                        <li><a href="https://www.mysql.com/support/">Support</a></li>
                    </ul>
                </div>

                <div class="links">
                    <ul>
                        <li class="top"><a href="https://www.mysql.com/downloads/">Downloads</a></li>
                        <li><a href="https://dev.mysql.com/downloads/mysql/">MySQL Community Server</a></li>
                        <li><a href="https://dev.mysql.com/downloads/cluster/">MySQL NDB Cluster</a></li>
                        <li><a href="https://dev.mysql.com/downloads/shell/">MySQL Shell</a></li>
                        <li><a href="https://dev.mysql.com/downloads/router/">MySQL Router</a></li>
                        <li><a href="https://dev.mysql.com/downloads/workbench/">MySQL Workbench</a></li>
                    </ul>
                </div>

                <div class="links">
                    <ul>
                        <li class="top"><a href="https://dev.mysql.com/doc/">Documentation</a></li>
                        <li><a href="https://dev.mysql.com/doc/refman/en/">MySQL Reference Manual</a></li>
                        <li><a href="https://dev.mysql.com/doc/workbench/en/">MySQL Workbench</a></li>
                        <li><a href="https://dev.mysql.com/doc/index-cluster.html">MySQL NDB Cluster</a></li>
                        <li><a href="https://dev.mysql.com/doc/index-connectors.html">MySQL Connectors</a></li>
                        <li><a href="https://dev.mysql.com/doc/#topic">Topic Guides</a></li>
                    </ul>
                </div>

                <div class="links">
                    <ul>
                        <li class="top"><a href="https://www.mysql.com/about/">About MySQL</a></li>
                        <li><a href="https://www.mysql.com/about/contact/">Contact Us</a></li>
                        <li><a href="https://blogs.oracle.com/mysql/">Blogs</a></li>
                                                                        <li><a href="https://www.mysql.com/buy-mysql/">How to Buy</a></li>
                        <li><a href="https://www.mysql.com/partners/">Partners</a></li>
                        <li><a href="https://www.mysql.com/about/jobs/">Job Opportunities</a></li>
                        <li><a href="https://www.mysql.com/sitemap.html">Site Map</a></li>
                    </ul>
                </div>

                            </div>

            <div id="footer-logo">
                <a href="http://www.oracle.com/" aria-label="Oracle" title="Oracle"><span class="oracle-logo"></span></a>
                &nbsp; <a href="https://www.oracle.com/legal/copyright.html">&copy; 2026 Oracle</a>
                <div class="footer-legal-links">
                    <a href="https://www.oracle.com/legal/privacy/">Privacy</a> /
                    <a href="https://www.oracle.com/legal/privacy/privacy-choices.html">Do Not Sell My Info</a> |
                    <a href="https://www.oracle.com/us/legal/terms/index.html">Terms of Use</a> |
                    <a href="https://www.oracle.com/us/legal/third-party-trademarks/index.html">Trademark Policy</a> |
                    <div id="teconsent"></div>
                </div>
            </div>

        </div>
    </footer>
</div>

            <script>
    if ((oracle.truste.api.getGdprConsentDecision().consentDecision) &&
            (oracle.truste.api.getGdprConsentDecision().consentDecision.indexOf(0) != -1 ||
             oracle.truste.api.getGdprConsentDecision().consentDecision.indexOf(2) != -1) )
    {
        document.write('<script src="https://labs.mysql.com/common/js/metrics/ora_mysql.js"><\/script>');
        document.write('<script type="text/javascript" async src="//c.oracleinfinity.io/acs/account/wh3g12c3gg/js/mysql/odc.js?_ora.context=analytics:production"><\/script>');
    }
    </script>

        
    
</body>
</html>
